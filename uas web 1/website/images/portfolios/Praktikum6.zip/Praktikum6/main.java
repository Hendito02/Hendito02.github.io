/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Praktikum6;

/**
 *
 * @author USER
 */
public class main {
    
    public static void main(String args[]){
       fMenuUtama m = new fMenuUtama();
       m.setVisible(true); 
    }
}
